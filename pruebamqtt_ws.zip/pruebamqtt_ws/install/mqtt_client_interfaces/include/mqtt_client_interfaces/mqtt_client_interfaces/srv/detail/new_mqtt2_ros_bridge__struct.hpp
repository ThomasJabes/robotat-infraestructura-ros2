// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from mqtt_client_interfaces:srv/NewMqtt2RosBridge.idl
// generated code does not contain a copyright notice

#ifndef MQTT_CLIENT_INTERFACES__SRV__DETAIL__NEW_MQTT2_ROS_BRIDGE__STRUCT_HPP_
#define MQTT_CLIENT_INTERFACES__SRV__DETAIL__NEW_MQTT2_ROS_BRIDGE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__mqtt_client_interfaces__srv__NewMqtt2RosBridge_Request __attribute__((deprecated))
#else
# define DEPRECATED__mqtt_client_interfaces__srv__NewMqtt2RosBridge_Request __declspec(deprecated)
#endif

namespace mqtt_client_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct NewMqtt2RosBridge_Request_
{
  using Type = NewMqtt2RosBridge_Request_<ContainerAllocator>;

  explicit NewMqtt2RosBridge_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::DEFAULTS_ONLY == _init)
    {
      this->primitive = false;
      this->mqtt_qos = 0;
      this->ros_queue_size = 1ul;
      this->ros_latched = false;
    } else if (rosidl_runtime_cpp::MessageInitialization::ZERO == _init) {
      this->ros_topic = "";
      this->mqtt_topic = "";
      this->primitive = false;
      this->mqtt_qos = 0;
      this->ros_queue_size = 0ul;
      this->ros_latched = false;
    }
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->ros_topic = "";
      this->mqtt_topic = "";
    }
  }

  explicit NewMqtt2RosBridge_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : ros_topic(_alloc),
    mqtt_topic(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::DEFAULTS_ONLY == _init)
    {
      this->primitive = false;
      this->mqtt_qos = 0;
      this->ros_queue_size = 1ul;
      this->ros_latched = false;
    } else if (rosidl_runtime_cpp::MessageInitialization::ZERO == _init) {
      this->ros_topic = "";
      this->mqtt_topic = "";
      this->primitive = false;
      this->mqtt_qos = 0;
      this->ros_queue_size = 0ul;
      this->ros_latched = false;
    }
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->ros_topic = "";
      this->mqtt_topic = "";
    }
  }

  // field types and members
  using _ros_topic_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _ros_topic_type ros_topic;
  using _mqtt_topic_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _mqtt_topic_type mqtt_topic;
  using _primitive_type =
    bool;
  _primitive_type primitive;
  using _mqtt_qos_type =
    uint8_t;
  _mqtt_qos_type mqtt_qos;
  using _ros_queue_size_type =
    uint32_t;
  _ros_queue_size_type ros_queue_size;
  using _ros_latched_type =
    bool;
  _ros_latched_type ros_latched;

  // setters for named parameter idiom
  Type & set__ros_topic(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->ros_topic = _arg;
    return *this;
  }
  Type & set__mqtt_topic(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->mqtt_topic = _arg;
    return *this;
  }
  Type & set__primitive(
    const bool & _arg)
  {
    this->primitive = _arg;
    return *this;
  }
  Type & set__mqtt_qos(
    const uint8_t & _arg)
  {
    this->mqtt_qos = _arg;
    return *this;
  }
  Type & set__ros_queue_size(
    const uint32_t & _arg)
  {
    this->ros_queue_size = _arg;
    return *this;
  }
  Type & set__ros_latched(
    const bool & _arg)
  {
    this->ros_latched = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    mqtt_client_interfaces::srv::NewMqtt2RosBridge_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const mqtt_client_interfaces::srv::NewMqtt2RosBridge_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<mqtt_client_interfaces::srv::NewMqtt2RosBridge_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<mqtt_client_interfaces::srv::NewMqtt2RosBridge_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      mqtt_client_interfaces::srv::NewMqtt2RosBridge_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<mqtt_client_interfaces::srv::NewMqtt2RosBridge_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      mqtt_client_interfaces::srv::NewMqtt2RosBridge_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<mqtt_client_interfaces::srv::NewMqtt2RosBridge_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<mqtt_client_interfaces::srv::NewMqtt2RosBridge_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<mqtt_client_interfaces::srv::NewMqtt2RosBridge_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__mqtt_client_interfaces__srv__NewMqtt2RosBridge_Request
    std::shared_ptr<mqtt_client_interfaces::srv::NewMqtt2RosBridge_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__mqtt_client_interfaces__srv__NewMqtt2RosBridge_Request
    std::shared_ptr<mqtt_client_interfaces::srv::NewMqtt2RosBridge_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const NewMqtt2RosBridge_Request_ & other) const
  {
    if (this->ros_topic != other.ros_topic) {
      return false;
    }
    if (this->mqtt_topic != other.mqtt_topic) {
      return false;
    }
    if (this->primitive != other.primitive) {
      return false;
    }
    if (this->mqtt_qos != other.mqtt_qos) {
      return false;
    }
    if (this->ros_queue_size != other.ros_queue_size) {
      return false;
    }
    if (this->ros_latched != other.ros_latched) {
      return false;
    }
    return true;
  }
  bool operator!=(const NewMqtt2RosBridge_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct NewMqtt2RosBridge_Request_

// alias to use template instance with default allocator
using NewMqtt2RosBridge_Request =
  mqtt_client_interfaces::srv::NewMqtt2RosBridge_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace mqtt_client_interfaces


#ifndef _WIN32
# define DEPRECATED__mqtt_client_interfaces__srv__NewMqtt2RosBridge_Response __attribute__((deprecated))
#else
# define DEPRECATED__mqtt_client_interfaces__srv__NewMqtt2RosBridge_Response __declspec(deprecated)
#endif

namespace mqtt_client_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct NewMqtt2RosBridge_Response_
{
  using Type = NewMqtt2RosBridge_Response_<ContainerAllocator>;

  explicit NewMqtt2RosBridge_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
    }
  }

  explicit NewMqtt2RosBridge_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
    }
  }

  // field types and members
  using _success_type =
    bool;
  _success_type success;

  // setters for named parameter idiom
  Type & set__success(
    const bool & _arg)
  {
    this->success = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    mqtt_client_interfaces::srv::NewMqtt2RosBridge_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const mqtt_client_interfaces::srv::NewMqtt2RosBridge_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<mqtt_client_interfaces::srv::NewMqtt2RosBridge_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<mqtt_client_interfaces::srv::NewMqtt2RosBridge_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      mqtt_client_interfaces::srv::NewMqtt2RosBridge_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<mqtt_client_interfaces::srv::NewMqtt2RosBridge_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      mqtt_client_interfaces::srv::NewMqtt2RosBridge_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<mqtt_client_interfaces::srv::NewMqtt2RosBridge_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<mqtt_client_interfaces::srv::NewMqtt2RosBridge_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<mqtt_client_interfaces::srv::NewMqtt2RosBridge_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__mqtt_client_interfaces__srv__NewMqtt2RosBridge_Response
    std::shared_ptr<mqtt_client_interfaces::srv::NewMqtt2RosBridge_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__mqtt_client_interfaces__srv__NewMqtt2RosBridge_Response
    std::shared_ptr<mqtt_client_interfaces::srv::NewMqtt2RosBridge_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const NewMqtt2RosBridge_Response_ & other) const
  {
    if (this->success != other.success) {
      return false;
    }
    return true;
  }
  bool operator!=(const NewMqtt2RosBridge_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct NewMqtt2RosBridge_Response_

// alias to use template instance with default allocator
using NewMqtt2RosBridge_Response =
  mqtt_client_interfaces::srv::NewMqtt2RosBridge_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace mqtt_client_interfaces

namespace mqtt_client_interfaces
{

namespace srv
{

struct NewMqtt2RosBridge
{
  using Request = mqtt_client_interfaces::srv::NewMqtt2RosBridge_Request;
  using Response = mqtt_client_interfaces::srv::NewMqtt2RosBridge_Response;
};

}  // namespace srv

}  // namespace mqtt_client_interfaces

#endif  // MQTT_CLIENT_INTERFACES__SRV__DETAIL__NEW_MQTT2_ROS_BRIDGE__STRUCT_HPP_
