// generated from rosidl_generator_py/resource/_idl_support.c.em
// with input from mqtt_client_interfaces:srv/NewMqtt2RosBridge.idl
// generated code does not contain a copyright notice
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <Python.h>
#include <stdbool.h>
#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-function"
#endif
#include "numpy/ndarrayobject.h"
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif
#include "rosidl_runtime_c/visibility_control.h"
#include "mqtt_client_interfaces/srv/detail/new_mqtt2_ros_bridge__struct.h"
#include "mqtt_client_interfaces/srv/detail/new_mqtt2_ros_bridge__functions.h"

#include "rosidl_runtime_c/string.h"
#include "rosidl_runtime_c/string_functions.h"


ROSIDL_GENERATOR_C_EXPORT
bool mqtt_client_interfaces__srv__new_mqtt2_ros_bridge__request__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[75];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("mqtt_client_interfaces.srv._new_mqtt2_ros_bridge.NewMqtt2RosBridge_Request", full_classname_dest, 74) == 0);
  }
  mqtt_client_interfaces__srv__NewMqtt2RosBridge_Request * ros_message = _ros_message;
  {  // ros_topic
    PyObject * field = PyObject_GetAttrString(_pymsg, "ros_topic");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->ros_topic, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }
  {  // mqtt_topic
    PyObject * field = PyObject_GetAttrString(_pymsg, "mqtt_topic");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->mqtt_topic, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }
  {  // primitive
    PyObject * field = PyObject_GetAttrString(_pymsg, "primitive");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->primitive = (Py_True == field);
    Py_DECREF(field);
  }
  {  // mqtt_qos
    PyObject * field = PyObject_GetAttrString(_pymsg, "mqtt_qos");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->mqtt_qos = (uint8_t)PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // ros_queue_size
    PyObject * field = PyObject_GetAttrString(_pymsg, "ros_queue_size");
    if (!field) {
      return false;
    }
    assert(PyLong_Check(field));
    ros_message->ros_queue_size = PyLong_AsUnsignedLong(field);
    Py_DECREF(field);
  }
  {  // ros_latched
    PyObject * field = PyObject_GetAttrString(_pymsg, "ros_latched");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->ros_latched = (Py_True == field);
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * mqtt_client_interfaces__srv__new_mqtt2_ros_bridge__request__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of NewMqtt2RosBridge_Request */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("mqtt_client_interfaces.srv._new_mqtt2_ros_bridge");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "NewMqtt2RosBridge_Request");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  mqtt_client_interfaces__srv__NewMqtt2RosBridge_Request * ros_message = (mqtt_client_interfaces__srv__NewMqtt2RosBridge_Request *)raw_ros_message;
  {  // ros_topic
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->ros_topic.data,
      strlen(ros_message->ros_topic.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "ros_topic", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // mqtt_topic
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->mqtt_topic.data,
      strlen(ros_message->mqtt_topic.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "mqtt_topic", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // primitive
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->primitive ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "primitive", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // mqtt_qos
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->mqtt_qos);
    {
      int rc = PyObject_SetAttrString(_pymessage, "mqtt_qos", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // ros_queue_size
    PyObject * field = NULL;
    field = PyLong_FromUnsignedLong(ros_message->ros_queue_size);
    {
      int rc = PyObject_SetAttrString(_pymessage, "ros_queue_size", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // ros_latched
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->ros_latched ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "ros_latched", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}

#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
// already included above
// #include <Python.h>
// already included above
// #include <stdbool.h>
// already included above
// #include "numpy/ndarrayobject.h"
// already included above
// #include "rosidl_runtime_c/visibility_control.h"
// already included above
// #include "mqtt_client_interfaces/srv/detail/new_mqtt2_ros_bridge__struct.h"
// already included above
// #include "mqtt_client_interfaces/srv/detail/new_mqtt2_ros_bridge__functions.h"


ROSIDL_GENERATOR_C_EXPORT
bool mqtt_client_interfaces__srv__new_mqtt2_ros_bridge__response__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[76];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("mqtt_client_interfaces.srv._new_mqtt2_ros_bridge.NewMqtt2RosBridge_Response", full_classname_dest, 75) == 0);
  }
  mqtt_client_interfaces__srv__NewMqtt2RosBridge_Response * ros_message = _ros_message;
  {  // success
    PyObject * field = PyObject_GetAttrString(_pymsg, "success");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->success = (Py_True == field);
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * mqtt_client_interfaces__srv__new_mqtt2_ros_bridge__response__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of NewMqtt2RosBridge_Response */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("mqtt_client_interfaces.srv._new_mqtt2_ros_bridge");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "NewMqtt2RosBridge_Response");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  mqtt_client_interfaces__srv__NewMqtt2RosBridge_Response * ros_message = (mqtt_client_interfaces__srv__NewMqtt2RosBridge_Response *)raw_ros_message;
  {  // success
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->success ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "success", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}
