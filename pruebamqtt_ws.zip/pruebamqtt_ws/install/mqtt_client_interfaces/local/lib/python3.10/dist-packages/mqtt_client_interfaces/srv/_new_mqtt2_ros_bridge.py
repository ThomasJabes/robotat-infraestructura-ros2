# generated from rosidl_generator_py/resource/_idl.py.em
# with input from mqtt_client_interfaces:srv/NewMqtt2RosBridge.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_NewMqtt2RosBridge_Request(type):
    """Metaclass of message 'NewMqtt2RosBridge_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('mqtt_client_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'mqtt_client_interfaces.srv.NewMqtt2RosBridge_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__new_mqtt2_ros_bridge__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__new_mqtt2_ros_bridge__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__new_mqtt2_ros_bridge__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__new_mqtt2_ros_bridge__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__new_mqtt2_ros_bridge__request

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'PRIMITIVE__DEFAULT': False,
            'MQTT_QOS__DEFAULT': 0,
            'ROS_QUEUE_SIZE__DEFAULT': 1,
            'ROS_LATCHED__DEFAULT': False,
        }

    @property
    def PRIMITIVE__DEFAULT(cls):
        """Return default value for message field 'primitive'."""
        return False

    @property
    def MQTT_QOS__DEFAULT(cls):
        """Return default value for message field 'mqtt_qos'."""
        return 0

    @property
    def ROS_QUEUE_SIZE__DEFAULT(cls):
        """Return default value for message field 'ros_queue_size'."""
        return 1

    @property
    def ROS_LATCHED__DEFAULT(cls):
        """Return default value for message field 'ros_latched'."""
        return False


class NewMqtt2RosBridge_Request(metaclass=Metaclass_NewMqtt2RosBridge_Request):
    """Message class 'NewMqtt2RosBridge_Request'."""

    __slots__ = [
        '_ros_topic',
        '_mqtt_topic',
        '_primitive',
        '_mqtt_qos',
        '_ros_queue_size',
        '_ros_latched',
    ]

    _fields_and_field_types = {
        'ros_topic': 'string',
        'mqtt_topic': 'string',
        'primitive': 'boolean',
        'mqtt_qos': 'uint8',
        'ros_queue_size': 'uint32',
        'ros_latched': 'boolean',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.ros_topic = kwargs.get('ros_topic', str())
        self.mqtt_topic = kwargs.get('mqtt_topic', str())
        self.primitive = kwargs.get(
            'primitive', NewMqtt2RosBridge_Request.PRIMITIVE__DEFAULT)
        self.mqtt_qos = kwargs.get(
            'mqtt_qos', NewMqtt2RosBridge_Request.MQTT_QOS__DEFAULT)
        self.ros_queue_size = kwargs.get(
            'ros_queue_size', NewMqtt2RosBridge_Request.ROS_QUEUE_SIZE__DEFAULT)
        self.ros_latched = kwargs.get(
            'ros_latched', NewMqtt2RosBridge_Request.ROS_LATCHED__DEFAULT)

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.ros_topic != other.ros_topic:
            return False
        if self.mqtt_topic != other.mqtt_topic:
            return False
        if self.primitive != other.primitive:
            return False
        if self.mqtt_qos != other.mqtt_qos:
            return False
        if self.ros_queue_size != other.ros_queue_size:
            return False
        if self.ros_latched != other.ros_latched:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def ros_topic(self):
        """Message field 'ros_topic'."""
        return self._ros_topic

    @ros_topic.setter
    def ros_topic(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'ros_topic' field must be of type 'str'"
        self._ros_topic = value

    @builtins.property
    def mqtt_topic(self):
        """Message field 'mqtt_topic'."""
        return self._mqtt_topic

    @mqtt_topic.setter
    def mqtt_topic(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'mqtt_topic' field must be of type 'str'"
        self._mqtt_topic = value

    @builtins.property
    def primitive(self):
        """Message field 'primitive'."""
        return self._primitive

    @primitive.setter
    def primitive(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'primitive' field must be of type 'bool'"
        self._primitive = value

    @builtins.property
    def mqtt_qos(self):
        """Message field 'mqtt_qos'."""
        return self._mqtt_qos

    @mqtt_qos.setter
    def mqtt_qos(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'mqtt_qos' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'mqtt_qos' field must be an unsigned integer in [0, 255]"
        self._mqtt_qos = value

    @builtins.property
    def ros_queue_size(self):
        """Message field 'ros_queue_size'."""
        return self._ros_queue_size

    @ros_queue_size.setter
    def ros_queue_size(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'ros_queue_size' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'ros_queue_size' field must be an unsigned integer in [0, 4294967295]"
        self._ros_queue_size = value

    @builtins.property
    def ros_latched(self):
        """Message field 'ros_latched'."""
        return self._ros_latched

    @ros_latched.setter
    def ros_latched(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'ros_latched' field must be of type 'bool'"
        self._ros_latched = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_NewMqtt2RosBridge_Response(type):
    """Metaclass of message 'NewMqtt2RosBridge_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('mqtt_client_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'mqtt_client_interfaces.srv.NewMqtt2RosBridge_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__new_mqtt2_ros_bridge__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__new_mqtt2_ros_bridge__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__new_mqtt2_ros_bridge__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__new_mqtt2_ros_bridge__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__new_mqtt2_ros_bridge__response

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class NewMqtt2RosBridge_Response(metaclass=Metaclass_NewMqtt2RosBridge_Response):
    """Message class 'NewMqtt2RosBridge_Response'."""

    __slots__ = [
        '_success',
    ]

    _fields_and_field_types = {
        'success': 'boolean',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.success = kwargs.get('success', bool())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.success != other.success:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def success(self):
        """Message field 'success'."""
        return self._success

    @success.setter
    def success(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'success' field must be of type 'bool'"
        self._success = value


class Metaclass_NewMqtt2RosBridge(type):
    """Metaclass of service 'NewMqtt2RosBridge'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('mqtt_client_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'mqtt_client_interfaces.srv.NewMqtt2RosBridge')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__new_mqtt2_ros_bridge

            from mqtt_client_interfaces.srv import _new_mqtt2_ros_bridge
            if _new_mqtt2_ros_bridge.Metaclass_NewMqtt2RosBridge_Request._TYPE_SUPPORT is None:
                _new_mqtt2_ros_bridge.Metaclass_NewMqtt2RosBridge_Request.__import_type_support__()
            if _new_mqtt2_ros_bridge.Metaclass_NewMqtt2RosBridge_Response._TYPE_SUPPORT is None:
                _new_mqtt2_ros_bridge.Metaclass_NewMqtt2RosBridge_Response.__import_type_support__()


class NewMqtt2RosBridge(metaclass=Metaclass_NewMqtt2RosBridge):
    from mqtt_client_interfaces.srv._new_mqtt2_ros_bridge import NewMqtt2RosBridge_Request as Request
    from mqtt_client_interfaces.srv._new_mqtt2_ros_bridge import NewMqtt2RosBridge_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
