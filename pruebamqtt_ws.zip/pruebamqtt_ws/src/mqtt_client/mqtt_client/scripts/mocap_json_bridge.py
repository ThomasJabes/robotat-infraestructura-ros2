#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import json
from std_msgs.msg import String
from geometry_msgs.msg import PoseStamped


class MocapJsonBridge(Node):
    def __init__(self):
        super().__init__('mocap_json_bridge')

        # ================================
        # 🛰️  Suscripción al JSON MQTT
        # ================================
        self.subscription = self.create_subscription(
            String,
            '/optitrack/data',
            self.listener_callback,
            5
        )

        # ================================
        # 🎯 Definición de IDs / tópicos
        # ================================
        # Metas
        self.meta_ids = {
            "69": "Meta_1",
            "63": "Meta_2",
            "62": "Meta_3",
            "65": "Meta_4",
            "67": "Meta_5"
        }

        # Pololus (3–9 y 11–13)
        self.pololu_ids = {str(i): f"pololu_{i}" for i in list(range(3, 10)) + list(range(11, 14))}

        # Combinar ambos diccionarios
        self.id_name_map = {**self.meta_ids, **self.pololu_ids}

        # ================================
        # 🧩 Crear publicadores dinámicos
        # ================================
        self._pub_map = {}

        for id_str, name in self.id_name_map.items():
            topic_name = f"/{name}/pose"
            self._pub_map[id_str] = self.create_publisher(PoseStamped, topic_name, 10)
            self.get_logger().info(f"✅ Creado publicador para {topic_name} (ID={id_str})")

    # ================================
    # 🔁 Callback principal
    # ================================
    def listener_callback(self, msg: String):
        try:
            data = json.loads(msg.data)

            # Solo procesar mensajes tipo POSE
            if data.get("type") != "POSE":
                return

            identifier = str(data.get("identifier"))
            if identifier not in self._pub_map:
                return  # ignorar IDs que no están configurados

            # Extraer pose del JSON
            pose_dict = data.get("payload", {}).get("pose", {})
            pos = pose_dict.get("position", {})
            rot = pose_dict.get("rotation", {})

            pose_msg = PoseStamped()
            pose_msg.header.stamp = self.get_clock().now().to_msg()
            pose_msg.header.frame_id = "optitrack"

            pose_msg.pose.position.x = float(pos.get("x", 0.0))
            pose_msg.pose.position.y = float(pos.get("y", 0.0))
            pose_msg.pose.position.z = float(pos.get("z", 0.0))

            pose_msg.pose.orientation.x = float(rot.get("qx", 0.0))
            pose_msg.pose.orientation.y = float(rot.get("qy", 0.0))
            pose_msg.pose.orientation.z = float(rot.get("qz", 0.0))
            pose_msg.pose.orientation.w = float(rot.get("qw", 1.0))

            # Publicar en el tópico correspondiente
            pub = self._pub_map[identifier]
            pub.publish(pose_msg)
            topic_name = getattr(pub, "topic_name", f"ID={identifier}")
            self.get_logger().info(f"Publicado en {topic_name} (ID={identifier})")

        except Exception as e:
            self.get_logger().warn(f"Error parseando JSON: {e}")


# ================================
# 🚀 Punto de entrada
# ================================
def main(args=None):
    rclpy.init(args=args)
    node = MocapJsonBridge()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

